﻿namespace Konbini.Messages.Enums
{
    public enum MdbCashlessResponseResult
    {
        None,
        CardSwiped,
        Failed,
        VendApproved,
        VendSuccess
    }
}
