﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Konbini.Messages.Enums
{
    public enum PaymentType
    {
        MdbCashless=100,
        Cyklone=101,
        IucApi=102
    }
}
