﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Konbini.Messages.Enums
{
    public enum CloudToMachineType
    {
        AllMachines,
        CurrentTenant,
        ToMachineId
    }
}
