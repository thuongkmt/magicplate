﻿using KonbiBrain.Common.Messages;

namespace Konbini.Messages.Commands
{
    public class MdbCashlessResponseCommand :UniversalCommands
    {
        public MdbCashlessResponseCommand() : base(UniversalCommandConstants.MdbCashlessReponse)
        {
            
        }
    }
}
