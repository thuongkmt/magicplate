(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/AppConsts.ts":
/*!******************************!*\
  !*** ./src/app/AppConsts.ts ***!
  \******************************/
/*! exports provided: AppConsts */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppConsts", function() { return AppConsts; });
var AppConsts = /** @class */ (function () {
    function AppConsts() {
    }
    return AppConsts;
}());



/***/ }),

/***/ "./src/app/AppPreBootstrap.ts":
/*!************************************!*\
  !*** ./src/app/AppPreBootstrap.ts ***!
  \************************************/
/*! exports provided: AppPreBootstrap */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppPreBootstrap", function() { return AppPreBootstrap; });
/* harmony import */ var _AppConsts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AppConsts */ "./src/app/AppConsts.ts");
/* harmony import */ var _shared_XmlHttpRequestHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shared/XmlHttpRequestHelper */ "./src/app/shared/XmlHttpRequestHelper.ts");


var AppPreBootstrap = /** @class */ (function () {
    function AppPreBootstrap() {
    }
    AppPreBootstrap.run = function (appRootUrl, callback, resolve, reject) {
        AppPreBootstrap.getApplicationConfig(appRootUrl, function () {
            callback();
        });
    };
    AppPreBootstrap.getApplicationConfig = function (appRootUrl, callback) {
        var type = 'GET';
        var url = appRootUrl + 'assets/appconfig.json';
        var customHeaders = [
            {
                name: 'konbiwalletapp'
            }
        ];
        _shared_XmlHttpRequestHelper__WEBPACK_IMPORTED_MODULE_1__["XmlHttpRequestHelper"].ajax(type, url, customHeaders, null, function (result) {
            console.log(result);
            _AppConsts__WEBPACK_IMPORTED_MODULE_0__["AppConsts"].magicBoxBackendurl = result.magicBoxBackendurl;
            _AppConsts__WEBPACK_IMPORTED_MODULE_0__["AppConsts"].webAdminBackendUrl = result.webAdminBackendUrl;
            _AppConsts__WEBPACK_IMPORTED_MODULE_0__["AppConsts"].rabbitMqStompUrl = result.rabbitMqStompUrl;
            _AppConsts__WEBPACK_IMPORTED_MODULE_0__["AppConsts"].rabbitMqUser = result.rabbitMqUser;
            _AppConsts__WEBPACK_IMPORTED_MODULE_0__["AppConsts"].rabbitMqUserPwd = result.rabbitMqUserPwd;
            callback();
        });
    };
    return AppPreBootstrap;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n\n   <app-layout>\n    <mat-sidenav-container>\n      <mat-sidenav #sidenav role=\"navigation\">\n        <app-sidenav-list (sidenavClose)=\"sidenav.close()\"></app-sidenav-list>\n      </mat-sidenav>\n      <mat-sidenav-content>\n        <app-header (sidenavToggle)=\"sidenav.toggle()\"></app-header>\n        <main style=\"height:100%;\">\n          <router-outlet></router-outlet>\n        </main>\n      </mat-sidenav-content>\n    </mat-sidenav-container>\n  </app-layout>"

/***/ }),

/***/ "./src/app/app.component.sass":
/*!************************************!*\
  !*** ./src/app/app.component.sass ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "mat-sidenav-container, mat-sidenav-content, mat-sidenav {\n  height: 100%; }\n\nmat-sidenav {\n  width: 250px; }\n\nmain {\n  padding: 10px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQzpcXERhdGFcXEtvbmJpbmlcXFRGU1xcU3RhbmRhcmRDbG91ZFxcU3RhbmRhcmRDbG91ZFxcVjJcXEtvbmJpLk1hY2hpbmVCcmFpblxcRGV2aWNlc1xca29uYml3YWxsZXRhcHAvc3JjXFxhcHBcXGFwcC5jb21wb25lbnQuc2FzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQVksRUFBQTs7QUFHaEI7RUFDSSxZQUFZLEVBQUE7O0FBR2hCO0VBQ0ksYUFBYSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5zYXNzIiwic291cmNlc0NvbnRlbnQiOlsibWF0LXNpZGVuYXYtY29udGFpbmVyLCBtYXQtc2lkZW5hdi1jb250ZW50LCBtYXQtc2lkZW5hdiB7XG4gICAgaGVpZ2h0OiAxMDAlOyB9XG5cblxubWF0LXNpZGVuYXYge1xuICAgIHdpZHRoOiAyNTBweDsgfVxuXG5cbm1haW4ge1xuICAgIHBhZGRpbmc6IDEwcHg7IH1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
    }
    AppComponent.prototype.ngOnInit = function () {
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.sass */ "./src/app/app.component.sass")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: getBaseHref, appInitializerFactory, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBaseHref", function() { return getBaseHref; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appInitializerFactory", function() { return appInitializerFactory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/esm5/toolbar.es5.js");
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/card */ "./node_modules/@angular/material/esm5/card.es5.js");
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/button */ "./node_modules/@angular/material/esm5/button.es5.js");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm5/service-worker.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _zxing_ngx_scanner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @zxing/ngx-scanner */ "./node_modules/@zxing/ngx-scanner/esm5/zxing-ngx-scanner.js");
/* harmony import */ var _nav_nav_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./nav/nav.component */ "./src/app/nav/nav.component.ts");
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/cdk/layout */ "./node_modules/@angular/cdk/esm5/layout.es5.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _routing_routing_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./routing/routing.module */ "./src/app/routing/routing.module.ts");
/* harmony import */ var _navigation_header_header_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./navigation/header/header.component */ "./src/app/navigation/header/header.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _layout_layout_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./layout/layout.component */ "./src/app/layout/layout.component.ts");
/* harmony import */ var _navigation_sidenav_list_sidenav_list_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./navigation/sidenav-list/sidenav-list.component */ "./src/app/navigation/sidenav-list/sidenav-list.component.ts");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/material/menu */ "./node_modules/@angular/material/esm5/menu.es5.js");
/* harmony import */ var _credit_credit_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./credit/credit.component */ "./src/app/credit/credit.component.ts");
/* harmony import */ var _scanqr_scanqr_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./scanqr/scanqr.component */ "./src/app/scanqr/scanqr.component.ts");
/* harmony import */ var _stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @stomp/ng2-stompjs */ "./node_modules/@stomp/ng2-stompjs/fesm5/stomp-ng2-stompjs.js");
/* harmony import */ var _assets_my_rx_stomp_config__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../assets/my-rx-stomp.config */ "./src/assets/my-rx-stomp.config.ts");
/* harmony import */ var _messages_messages_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./messages/messages.component */ "./src/app/messages/messages.component.ts");
/* harmony import */ var _AppPreBootstrap__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./AppPreBootstrap */ "./src/app/AppPreBootstrap.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _AppConsts__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./AppConsts */ "./src/app/AppConsts.ts");







/*...*/














// import { MatTabsModule } from '@angular/material';









//firebase.initializeApp(firebaseConfig);
function getBaseHref(platformLocation) {
    var baseUrl = platformLocation.getBaseHrefFromDOM();
    if (baseUrl) {
        return baseUrl;
    }
    return '/';
}
function getDocumentOrigin() {
    if (!document.location.origin) {
        return document.location.protocol + '//' + document.location.hostname + (document.location.port ? ':' + document.location.port : '');
    }
    return document.location.origin;
}
function appInitializerFactory(injector, platformLocation) {
    return function () {
        return new Promise(function (resolve, reject) {
            _AppConsts__WEBPACK_IMPORTED_MODULE_29__["AppConsts"].appBaseHref = getBaseHref(platformLocation);
            var appBaseUrl = getDocumentOrigin() + _AppConsts__WEBPACK_IMPORTED_MODULE_29__["AppConsts"].appBaseHref;
            console.log('pre initialize app');
            _AppPreBootstrap__WEBPACK_IMPORTED_MODULE_27__["AppPreBootstrap"].run(appBaseUrl, function () {
                console.log('init finished');
                resolve(true);
            }, resolve, reject);
        });
    };
}
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                _nav_nav_component__WEBPACK_IMPORTED_MODULE_13__["NavComponent"],
                _navigation_header_header_component__WEBPACK_IMPORTED_MODULE_17__["HeaderComponent"],
                _layout_layout_component__WEBPACK_IMPORTED_MODULE_19__["LayoutComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_18__["HomeComponent"],
                _navigation_sidenav_list_sidenav_list_component__WEBPACK_IMPORTED_MODULE_20__["SidenavListComponent"],
                _credit_credit_component__WEBPACK_IMPORTED_MODULE_22__["CreditComponent"],
                _scanqr_scanqr_component__WEBPACK_IMPORTED_MODULE_23__["ScanqrComponent"],
                _credit_credit_component__WEBPACK_IMPORTED_MODULE_22__["OpenDoorConfirmDialogComponent"],
                _credit_credit_component__WEBPACK_IMPORTED_MODULE_22__["TransactionSuccessDialogComponent"],
                _credit_credit_component__WEBPACK_IMPORTED_MODULE_22__["TransactionStartDialogComponent"],
                _messages_messages_component__WEBPACK_IMPORTED_MODULE_26__["MessagesComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["BrowserAnimationsModule"],
                _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_7__["MatToolbarModule"],
                _angular_material_card__WEBPACK_IMPORTED_MODULE_8__["MatCardModule"],
                _angular_material_button__WEBPACK_IMPORTED_MODULE_9__["MatButtonModule"],
                _zxing_ngx_scanner__WEBPACK_IMPORTED_MODULE_12__["ZXingScannerModule"],
                _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].production }),
                _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_14__["LayoutModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_15__["MatSidenavModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_15__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_15__["MatListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_15__["MatSidenavModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_15__["MatTabsModule"],
                _angular_material_menu__WEBPACK_IMPORTED_MODULE_21__["MatMenuModule"],
                _routing_routing_module__WEBPACK_IMPORTED_MODULE_16__["RoutingModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_15__["MatDialogModule"]
            ],
            entryComponents: [_credit_credit_component__WEBPACK_IMPORTED_MODULE_22__["OpenDoorConfirmDialogComponent"], _credit_credit_component__WEBPACK_IMPORTED_MODULE_22__["TransactionSuccessDialogComponent"], _credit_credit_component__WEBPACK_IMPORTED_MODULE_22__["TransactionStartDialogComponent"]],
            exports: [_angular_material_toolbar__WEBPACK_IMPORTED_MODULE_7__["MatToolbarModule"]],
            providers: [
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_28__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_28__["HashLocationStrategy"] },
                {
                    provide: _stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_24__["InjectableRxStompConfig"],
                    useValue: _assets_my_rx_stomp_config__WEBPACK_IMPORTED_MODULE_25__["myRxStompConfig"]
                },
                {
                    provide: _stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_24__["RxStompService"],
                    useFactory: _stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_24__["rxStompServiceFactory"],
                    deps: [_stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_24__["InjectableRxStompConfig"]]
                },
                {
                    provide: _angular_core__WEBPACK_IMPORTED_MODULE_2__["APP_INITIALIZER"],
                    useFactory: appInitializerFactory,
                    deps: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injector"], _angular_common__WEBPACK_IMPORTED_MODULE_28__["PlatformLocation"]],
                    multi: true
                },
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/credit/confirm-open-door-dialog.html":
/*!******************************************************!*\
  !*** ./src/app/credit/confirm-open-door-dialog.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h2 mat-dialog-title>Confirm open door</h2>\r\n<mat-dialog-content class=\"mat-typography\">\r\n  You are at magicbox Konbini01, please confirm to open magicbox door.\r\n</mat-dialog-content>\r\n<mat-dialog-actions align=\"end\">\r\n  <button mat-button mat-dialog-close color=\"warn\"> Cancel</button>\r\n  <button mat-button [mat-dialog-close]=\"true\" color=\"green\" cdkFocusInitial>Confirm</button>\r\n</mat-dialog-actions>\r\n"

/***/ }),

/***/ "./src/app/credit/credit.component.css":
/*!*********************************************!*\
  !*** ./src/app/credit/credit.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".user-card {\r\n  /* max-width: 400px; */\r\n}\r\n\r\n.user-header-image {\r\n  background-image: url('https://material.angular.io/assets/img/examples/shiba1.jpg');\r\n  background-size: cover;\r\n}\r\n\r\n.align-center{\r\n  display:flex;\r\n  justify-content:center;\r\n  align-items:center;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3JlZGl0L2NyZWRpdC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0UsbUZBQW1GO0VBQ25GLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLFlBQVk7RUFDWixzQkFBc0I7RUFDdEIsa0JBQWtCO0FBQ3BCIiwiZmlsZSI6InNyYy9hcHAvY3JlZGl0L2NyZWRpdC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnVzZXItY2FyZCB7XHJcbiAgLyogbWF4LXdpZHRoOiA0MDBweDsgKi9cclxufVxyXG5cclxuLnVzZXItaGVhZGVyLWltYWdlIHtcclxuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJ2h0dHBzOi8vbWF0ZXJpYWwuYW5ndWxhci5pby9hc3NldHMvaW1nL2V4YW1wbGVzL3NoaWJhMS5qcGcnKTtcclxuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG59XHJcblxyXG4uYWxpZ24tY2VudGVye1xyXG4gIGRpc3BsYXk6ZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6Y2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOmNlbnRlcjtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/credit/credit.component.html":
/*!**********************************************!*\
  !*** ./src/app/credit/credit.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card class=\"user-card\">\n  <mat-card-header>\n    <div mat-card-avatar class=\"user-header-image\"></div>\n    <mat-card-title>Ha Doan</mat-card-title>\n    <mat-card-subtitle>Developer</mat-card-subtitle>\n  </mat-card-header>\n  \n  <mat-card-content>\n    \n    <h3 class=\"align-center\">\n    Balance</h3>\n\n    <p class=\"align-center\">{{currentCredit | currency }}</p>\n  </mat-card-content>\n  \n</mat-card>\n\n\n<mat-card class=\"qrcode-card\" >\n  <mat-card-content >\n      <h3 class=\"align-center\">Your Code</h3>\n      <p class=\"align-center\">\n        <img  mat-card-image src=\"../../assets/images/qrcode.png\" style=\"width:50%;\" alt=\"qrcode\">\n      </p>\n  </mat-card-content>\n  \n</mat-card>\n\n\n<mat-card class=\"other\" style=\"height:100%;\">\n  \n  <mat-card-content>\n    \n  &nbsp;\n\n  </mat-card-content>\n  \n</mat-card>\n\n<!-- <button mat-raised-button color=\"primary\" (click)=\"openButtonClick()\" >  Open</button> -->\n\n<!-- <app-messages></app-messages> -->\n"

/***/ }),

/***/ "./src/app/credit/credit.component.ts":
/*!********************************************!*\
  !*** ./src/app/credit/credit.component.ts ***!
  \********************************************/
/*! exports provided: CreditComponent, OpenDoorConfirmDialogComponent, TransactionSuccessDialogComponent, TransactionStartDialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreditComponent", function() { return CreditComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpenDoorConfirmDialogComponent", function() { return OpenDoorConfirmDialogComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactionSuccessDialogComponent", function() { return TransactionSuccessDialogComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TransactionStartDialogComponent", function() { return TransactionStartDialogComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @stomp/ng2-stompjs */ "./node_modules/@stomp/ng2-stompjs/fesm5/stomp-ng2-stompjs.js");
/* harmony import */ var _services_credit_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/credit.service */ "./src/app/services/credit.service.ts");





var CreditComponent = /** @class */ (function () {
    function CreditComponent(dialog, rxStompService, creditService) {
        this.dialog = dialog;
        this.rxStompService = rxStompService;
        this.creditService = creditService;
        console.log('credit module');
    }
    CreditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.topicSubscription = this.rxStompService.watch('/topic/demo').subscribe(function (message) {
            console.log(message.body);
            if (message.body === "HADOAN_CONFIRM_OPEN") {
                _this.openConfirmDialog();
            }
            if (message.body === "TRANSACTION_COMPLETED") {
                _this.reloadUserCredit();
                var dialogRef = _this.dialog.open(TransactionSuccessDialogComponent);
                dialogRef.afterClosed().subscribe();
            }
        });
        this.reloadUserCredit();
    };
    CreditComponent.prototype.reloadUserCredit = function () {
        var _this = this;
        this.creditService.getUserCredit('hadoan').subscribe(function (data) {
            _this.currentCredit = data.result;
        });
    };
    CreditComponent.prototype.ngOnDestroy = function () {
        this.topicSubscription.unsubscribe();
    };
    CreditComponent.prototype.openButtonClick = function () {
        var dialogRef = this.dialog.open(TransactionSuccessDialogComponent);
        dialogRef.afterClosed().subscribe();
        // this.creditService.getUserCredit('hadoan').subscribe((data) => {
        //   console.log(data)
        //   console.log(data.result);
        // });
    };
    CreditComponent.prototype.openConfirmDialog = function () {
        var _this = this;
        var dialogRef = this.dialog.open(OpenDoorConfirmDialogComponent);
        dialogRef.afterClosed().subscribe(function (result) {
            console.log("Dialog result: " + result);
            if (result) {
                //open fridge
                _this.creditService.startTransaction().subscribe(function () {
                    _this.dialog.open(TransactionStartDialogComponent).afterClosed().subscribe(function () { });
                });
            }
        });
    };
    CreditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-credit',
            template: __webpack_require__(/*! ./credit.component.html */ "./src/app/credit/credit.component.html"),
            styles: [__webpack_require__(/*! ./credit.component.css */ "./src/app/credit/credit.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatDialog"],
            _stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_3__["RxStompService"],
            _services_credit_service__WEBPACK_IMPORTED_MODULE_4__["CreditService"]])
    ], CreditComponent);
    return CreditComponent;
}());

var OpenDoorConfirmDialogComponent = /** @class */ (function () {
    function OpenDoorConfirmDialogComponent() {
    }
    OpenDoorConfirmDialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'confirm-open-door-dialog',
            template: __webpack_require__(/*! ./confirm-open-door-dialog.html */ "./src/app/credit/confirm-open-door-dialog.html"),
        })
    ], OpenDoorConfirmDialogComponent);
    return OpenDoorConfirmDialogComponent;
}());

var TransactionSuccessDialogComponent = /** @class */ (function () {
    function TransactionSuccessDialogComponent() {
    }
    TransactionSuccessDialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'transaction-success-dialog',
            template: __webpack_require__(/*! ./transaction-success-dialog.html */ "./src/app/credit/transaction-success-dialog.html"),
        })
    ], TransactionSuccessDialogComponent);
    return TransactionSuccessDialogComponent;
}());

var TransactionStartDialogComponent = /** @class */ (function () {
    function TransactionStartDialogComponent() {
    }
    TransactionStartDialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'transaction-start-dialog',
            template: __webpack_require__(/*! ./transaction-start-dialog.html */ "./src/app/credit/transaction-start-dialog.html"),
        })
    ], TransactionStartDialogComponent);
    return TransactionStartDialogComponent;
}());



/***/ }),

/***/ "./src/app/credit/transaction-start-dialog.html":
/*!******************************************************!*\
  !*** ./src/app/credit/transaction-start-dialog.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h2 mat-dialog-title>Infor</h2>\r\n<mat-dialog-content class=\"mat-typography\">\r\n  MagicBox is opening, please select your item then close the door to finish transaction.\r\n</mat-dialog-content>\r\n<mat-dialog-actions align=\"end\">\r\n  <button mat-button [mat-dialog-close]=\"true\" color=\"green\" cdkFocusInitial>Ok</button>\r\n</mat-dialog-actions>\r\n"

/***/ }),

/***/ "./src/app/credit/transaction-success-dialog.html":
/*!********************************************************!*\
  !*** ./src/app/credit/transaction-success-dialog.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h2 mat-dialog-title>Transaction success</h2>\r\n<mat-dialog-content class=\"mat-typography\">\r\n  Your transaction is success.\r\n</mat-dialog-content>\r\n<mat-dialog-actions align=\"end\">\r\n  <button mat-button [mat-dialog-close]=\"true\" color=\"green\" cdkFocusInitial>Ok</button>\r\n</mat-dialog-actions>\r\n"

/***/ }),

/***/ "./src/app/home/home.component.css":
/*!*****************************************!*\
  !*** ./src/app/home/home.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "section div p{\n    color: #3f51b5;\n    font-size: 30px;\n    text-shadow: 2px 3px 5px grey;\n    margin: 30px 0;\n}\n\nsection div + p{\n    color: #3f51b5;\n    font-weight: bold;\n    font-size: 20px;\n    padding-bottom: 20px;\n}\n\nmat-tab-group {\n    text-align: center;\n}\n\nmat-tab-group p {\n    padding-top: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtJQUNmLDZCQUE2QjtJQUM3QixjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksY0FBYztJQUNkLGlCQUFpQjtJQUNqQixlQUFlO0lBQ2Ysb0JBQW9CO0FBQ3hCOztBQUVBO0lBQ0ksa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksaUJBQWlCO0FBQ3JCIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJzZWN0aW9uIGRpdiBwe1xuICAgIGNvbG9yOiAjM2Y1MWI1O1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICB0ZXh0LXNoYWRvdzogMnB4IDNweCA1cHggZ3JleTtcbiAgICBtYXJnaW46IDMwcHggMDtcbn1cblxuc2VjdGlvbiBkaXYgKyBwe1xuICAgIGNvbG9yOiAjM2Y1MWI1O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBwYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cblxubWF0LXRhYi1ncm91cCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5tYXQtdGFiLWdyb3VwIHAge1xuICAgIHBhZGRpbmctdG9wOiAyMHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/home/home.component.html":
/*!******************************************!*\
  !*** ./src/app/home/home.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-toolbar  color=\"primary\">\n  <mat-toolbar-row>\n  <span>JS-jargon</span>\n  </mat-toolbar-row>\n  </mat-toolbar>\n  <main>\n      <div class=\"scanner-shell\" [hidden]=\"!hasDevices\">\n\n          <header>\n            <select (change)=\"onDeviceSelectChange($event.target.value)\">\n              <option value=\"\" [selected]=\"!currentDevice\">No Device Selected</option>\n              <option *ngFor=\"let device of availableDevices\" [value]=\"device.deviceId\" [selected]=\"currentDevice && device.deviceId === currentDevice.deviceId\">{{device.label}}</option>\n            </select>\n          </header>\n        \n          <zxing-scanner #scanner [device]=\"currentDevice\" (scanSuccess)=\"handleQrCodeResult($event)\" [formats]=\"['EAN_13', 'CODE_128', 'QR_CODE']\" [tryHarder]=\"true\"></zxing-scanner>\n        \n          <section class=\"results\" *ngIf=\"qrResultString\">\n            <small>Result</small>\n            <strong>{{ qrResultString }}</strong>\n          </section>\n        \n        </div>\n        \n        <ng-container *ngIf=\"hasPermission === undefined\">\n        \n          <h2>Waiting for permissions.</h2>\n        \n          <blockquote>\n            If your device does not has cameras, no permissions will be asked.\n          </blockquote>\n        \n        </ng-container>\n        \n        <ng-container *ngIf=\"hasPermission === false\">\n        \n          <h2>You denied the camera permission, we can't scan anything without it. 😪</h2>\n        \n        </ng-container>\n        \n        <ng-container *ngIf=\"hasDevices === undefined\">\n        \n          <h2>Couldn't check for devices.</h2>\n        \n          <blockquote>\n            This may be caused by some security error.\n          </blockquote>\n        \n        </ng-container>\n        \n        <ng-container *ngIf=\"hasDevices === false\">\n        \n          <h2>No devices were found.</h2>\n        \n          <blockquote>\n            I believe your device has no media devices attached to.\n          </blockquote>\n        \n        </ng-container>\n        \n        <footer>\n          <table class=\"table-scanner-state\">\n            <thead>\n              <tr>\n                <th>Status</th>\n                <th>Property</th>\n              </tr>\n            </thead>\n            <tbody>\n              <tr>\n                <td>{{ stateToEmoji(hasDevices) }}</td>\n                <td>Devices</td>\n              </tr>\n              <tr>\n                <td>{{ stateToEmoji(hasPermission) }}</td>\n                <td>Permissions</td>\n              </tr>\n            </tbody>\n          </table>\n          <p class=\"ng-version\">Angular version: {{ ngVersion }}</p>\n        </footer>\n        \n\n  </main>\n  "

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _zxing_ngx_scanner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @zxing/ngx-scanner */ "./node_modules/@zxing/ngx-scanner/esm5/zxing-ngx-scanner.js");



var HomeComponent = /** @class */ (function () {
    /**
     *
     */
    function HomeComponent() {
        this.title = 'konbiwalletapp';
        this.ngVersion = _angular_core__WEBPACK_IMPORTED_MODULE_1__["VERSION"].full;
    }
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.scanner.camerasFound.subscribe(function (devices) {
            _this.hasDevices = true;
            _this.availableDevices = devices;
            // selects the devices's back camera by default
            // for (const device of devices) {
            //     if (/back|rear|environment/gi.test(device.label)) {
            //         this.scanner.changeDevice(device);
            //         this.currentDevice = device;
            //         break;
            //     }
            // }
        });
        this.scanner.camerasNotFound.subscribe(function () { return _this.hasDevices = false; });
        this.scanner.scanComplete.subscribe(function (result) { return _this.qrResult = result; });
        this.scanner.permissionResponse.subscribe(function (perm) { return _this.hasPermission = perm; });
    };
    HomeComponent.prototype.displayCameras = function (cameras) {
        console.debug('Devices: ', cameras);
        this.availableDevices = cameras;
    };
    HomeComponent.prototype.handleQrCodeResult = function (resultString) {
        console.debug('Result: ', resultString);
        this.qrResultString = resultString;
    };
    HomeComponent.prototype.onDeviceSelectChange = function (selectedValue) {
        console.debug('Selection changed: ', selectedValue);
        this.currentDevice = this.scanner.getDeviceById(selectedValue);
    };
    HomeComponent.prototype.stateToEmoji = function (state) {
        var states = {
            // not checked
            undefined: '❔',
            // failed to check
            null: '⭕',
            // success
            true: '✔',
            // can't touch that
            false: '❌'
        };
        return states['' + state];
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('scanner'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _zxing_ngx_scanner__WEBPACK_IMPORTED_MODULE_2__["ZXingScannerComponent"])
    ], HomeComponent.prototype, "scanner", void 0);
    HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/home/home.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/layout/layout.component.css":
/*!*********************************************!*\
  !*** ./src/app/layout/layout.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".layout-wrapper{\n    height: 100%;\n}\n\n.flex-wrapper{\n    height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGF5b3V0L2xheW91dC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksWUFBWTtBQUNoQjs7QUFFQTtJQUNJLFlBQVk7QUFDaEIiLCJmaWxlIjoic3JjL2FwcC9sYXlvdXQvbGF5b3V0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGF5b3V0LXdyYXBwZXJ7XG4gICAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uZmxleC13cmFwcGVye1xuICAgIGhlaWdodDogMTAwJTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/layout/layout.component.html":
/*!**********************************************!*\
  !*** ./src/app/layout/layout.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div fxLayout=\"row wrap\" fxLayoutAlign=\"center center\" class=\"layout-wrapper\" >\n  <div fxFlex=\"80%\" fxFlex.lt-md=\"100%\" class=\"flex-wrapper\">\n      <ng-content></ng-content>\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/layout/layout.component.ts":
/*!********************************************!*\
  !*** ./src/app/layout/layout.component.ts ***!
  \********************************************/
/*! exports provided: LayoutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LayoutComponent", function() { return LayoutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var LayoutComponent = /** @class */ (function () {
    function LayoutComponent() {
    }
    LayoutComponent.prototype.ngOnInit = function () {
    };
    LayoutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-layout',
            template: __webpack_require__(/*! ./layout.component.html */ "./src/app/layout/layout.component.html"),
            styles: [__webpack_require__(/*! ./layout.component.css */ "./src/app/layout/layout.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LayoutComponent);
    return LayoutComponent;
}());



/***/ }),

/***/ "./src/app/messages/messages.component.html":
/*!**************************************************!*\
  !*** ./src/app/messages/messages.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"messages\">\n  <button class=\"btn btn-primary\" (click)=\"onSendMessage()\">Send Test Message</button>\n  <h2>Received messages</h2>\n  <ol>\n      <!-- we will use Angular binding to populate list of messages -->\n      <li class=\"message\" *ngFor=\"let message of receivedMessages\">{{message}}</li>\n\n  </ol>\n</div>"

/***/ }),

/***/ "./src/app/messages/messages.component.sass":
/*!**************************************************!*\
  !*** ./src/app/messages/messages.component.sass ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lc3NhZ2VzL21lc3NhZ2VzLmNvbXBvbmVudC5zYXNzIn0= */"

/***/ }),

/***/ "./src/app/messages/messages.component.ts":
/*!************************************************!*\
  !*** ./src/app/messages/messages.component.ts ***!
  \************************************************/
/*! exports provided: MessagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagesComponent", function() { return MessagesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @stomp/ng2-stompjs */ "./node_modules/@stomp/ng2-stompjs/fesm5/stomp-ng2-stompjs.js");



var MessagesComponent = /** @class */ (function () {
    function MessagesComponent(rxStompService) {
        this.rxStompService = rxStompService;
        this.receivedMessages = [];
    }
    MessagesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.topicSubscription = this.rxStompService.watch('/topic/demo').subscribe(function (message) {
            console.log(message.body);
            _this.receivedMessages.push(message.body);
        });
    };
    MessagesComponent.prototype.ngOnDestroy = function () {
        this.topicSubscription.unsubscribe();
    };
    MessagesComponent.prototype.onSendMessage = function () {
        console.log('onmessage');
        var message = "Message generated at " + new Date;
        this.rxStompService.publish({ destination: '/topic/demo', body: message });
    };
    MessagesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-messages',
            template: __webpack_require__(/*! ./messages.component.html */ "./src/app/messages/messages.component.html"),
            styles: [__webpack_require__(/*! ./messages.component.sass */ "./src/app/messages/messages.component.sass")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_stomp_ng2_stompjs__WEBPACK_IMPORTED_MODULE_2__["RxStompService"]])
    ], MessagesComponent);
    return MessagesComponent;
}());



/***/ }),

/***/ "./src/app/nav/nav.component.css":
/*!***************************************!*\
  !*** ./src/app/nav/nav.component.css ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".sidenav-container {\n  height: 100%;\n}\n\n.sidenav {\n  width: 200px;\n}\n\n.sidenav .mat-toolbar {\n  background: inherit;\n}\n\n.mat-toolbar.mat-primary {\n  position: -webkit-sticky;\n  position: sticky;\n  top: 0;\n  z-index: 1;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbmF2L25hdi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBWTtBQUNkOztBQUVBO0VBQ0UsWUFBWTtBQUNkOztBQUVBO0VBQ0UsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0Usd0JBQWdCO0VBQWhCLGdCQUFnQjtFQUNoQixNQUFNO0VBQ04sVUFBVTtBQUNaIiwiZmlsZSI6InNyYy9hcHAvbmF2L25hdi5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNpZGVuYXYtY29udGFpbmVyIHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uc2lkZW5hdiB7XG4gIHdpZHRoOiAyMDBweDtcbn1cblxuLnNpZGVuYXYgLm1hdC10b29sYmFyIHtcbiAgYmFja2dyb3VuZDogaW5oZXJpdDtcbn1cblxuLm1hdC10b29sYmFyLm1hdC1wcmltYXJ5IHtcbiAgcG9zaXRpb246IHN0aWNreTtcbiAgdG9wOiAwO1xuICB6LWluZGV4OiAxO1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/nav/nav.component.html":
/*!****************************************!*\
  !*** ./src/app/nav/nav.component.html ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-sidenav-container class=\"sidenav-container\">\n  <mat-sidenav #drawer class=\"sidenav\" fixedInViewport=\"true\"\n      [attr.role]=\"(isHandset$ | async) ? 'dialog' : 'navigation'\"\n      [mode]=\"(isHandset$ | async) ? 'over' : 'side'\"\n      [opened]=\"!(isHandset$ | async)\">\n    <mat-toolbar>Menu</mat-toolbar>\n    <mat-nav-list>\n      <a mat-list-item href=\"#\">Link 1</a>\n      <a mat-list-item href=\"#\">Link 2</a>\n      <a mat-list-item href=\"#\">Link 3</a>\n    </mat-nav-list>\n  </mat-sidenav>\n  <mat-sidenav-content>\n    <mat-toolbar color=\"primary\">\n      <button\n        type=\"button\"\n        aria-label=\"Toggle sidenav\"\n        mat-icon-button\n        (click)=\"drawer.toggle()\"\n        *ngIf=\"isHandset$ | async\">\n        <mat-icon aria-label=\"Side nav toggle icon\">menu</mat-icon>\n      </button>\n      <span>konbiwalletapp</span>\n    </mat-toolbar>\n    <!-- Add Content Here -->\n  </mat-sidenav-content>\n</mat-sidenav-container>\n"

/***/ }),

/***/ "./src/app/nav/nav.component.ts":
/*!**************************************!*\
  !*** ./src/app/nav/nav.component.ts ***!
  \**************************************/
/*! exports provided: NavComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavComponent", function() { return NavComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/cdk/layout */ "./node_modules/@angular/cdk/esm5/layout.es5.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");




var NavComponent = /** @class */ (function () {
    function NavComponent(breakpointObserver) {
        this.breakpointObserver = breakpointObserver;
        this.isHandset$ = this.breakpointObserver.observe(_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["Breakpoints"].Handset)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (result) { return result.matches; }));
    }
    NavComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-nav',
            template: __webpack_require__(/*! ./nav.component.html */ "./src/app/nav/nav.component.html"),
            styles: [__webpack_require__(/*! ./nav.component.css */ "./src/app/nav/nav.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_cdk_layout__WEBPACK_IMPORTED_MODULE_2__["BreakpointObserver"]])
    ], NavComponent);
    return NavComponent;
}());



/***/ }),

/***/ "./src/app/navigation/header/header.component.html":
/*!*********************************************************!*\
  !*** ./src/app/navigation/header/header.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-toolbar color=\"primary\">\n  <div fxHide.gt-xs>\n      <button mat-icon-button (click)=\"onToggleSidenav()\">\n          <mat-icon>menu</mat-icon>\n      </button>\n  </div>\n  <div>\n      <a routerLink=\"/home\">User Credit</a>\n  </div>\n  <!-- <div fxFlex fxLayout fxLayoutAlign=\"end\" fxHide.xs>\n      <ul fxLayout fxLayoutGap=\"15px\" class=\"navigation-items\">\n          <li>\n              <a routerLink=\"/owner\">Owner Actions</a>\n          </li>\n          <li>\n              <a routerLink=\"/account\">Account Actions</a>\n          </li>\n      </ul>\n  </div> -->\n</mat-toolbar>"

/***/ }),

/***/ "./src/app/navigation/header/header.component.sass":
/*!*********************************************************!*\
  !*** ./src/app/navigation/header/header.component.sass ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL25hdmlnYXRpb24vaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2FzcyJ9 */"

/***/ }),

/***/ "./src/app/navigation/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/navigation/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
        var _this = this;
        this.sidenavToggle = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onToggleSidenav = function () {
            _this.sidenavToggle.emit();
        };
    }
    HeaderComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], HeaderComponent.prototype, "sidenavToggle", void 0);
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/navigation/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.sass */ "./src/app/navigation/header/header.component.sass")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/navigation/sidenav-list/sidenav-list.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/navigation/sidenav-list/sidenav-list.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-nav-list>\n  <a mat-list-item routerLink=\"/home\" (click)=\"onSidenavClose()\">\n    <mat-icon>home</mat-icon> <span class=\"nav-caption\">Home</span>\n  </a>\n  <!-- <a mat-list-item routerLink=\"/owner\" (click)=\"onSidenavClose()\">\n    <mat-icon>assignment_ind</mat-icon> <span class=\"nav-caption\">Owner Actions</span>\n  </a>\n  <a mat-list-item routerLink=\"#\" (click)=\"onSidenavClose()\">\n    <mat-icon>account_balance</mat-icon><span class=\"nav-caption\">Account Actions</span>\n  </a> -->\n  <mat-list-item [matMenuTriggerFor]=\"menu\">\n    <mat-icon>unfold_more</mat-icon>\n    <a matline>Transactions</a>\n  </mat-list-item>\n  <mat-menu #menu=\"matMenu\">\n    <button mat-menu-item (click)=\"onSidenavClose()\">Success</button>\n    <button mat-menu-item (click)=\"onSidenavClose()\">Error</button>\n  </mat-menu>\n<!-- \n  <mat-list-item [matMenuTriggerFor]=\"menu\">\n    <mat-icon>unfold_more</mat-icon>\n    <a matline>Example</a>\n  </mat-list-item>\n  <mat-menu #menu=\"matMenu\">\n    <button mat-menu-item (click)=\"onSidenavClose()\">View profile</button>\n    <button mat-menu-item (click)=\"onSidenavClose()\">Add contact</button>\n  </mat-menu> -->\n</mat-nav-list>"

/***/ }),

/***/ "./src/app/navigation/sidenav-list/sidenav-list.component.sass":
/*!*********************************************************************!*\
  !*** ./src/app/navigation/sidenav-list/sidenav-list.component.sass ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL25hdmlnYXRpb24vc2lkZW5hdi1saXN0L3NpZGVuYXYtbGlzdC5jb21wb25lbnQuc2FzcyJ9 */"

/***/ }),

/***/ "./src/app/navigation/sidenav-list/sidenav-list.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/navigation/sidenav-list/sidenav-list.component.ts ***!
  \*******************************************************************/
/*! exports provided: SidenavListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SidenavListComponent", function() { return SidenavListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SidenavListComponent = /** @class */ (function () {
    function SidenavListComponent() {
        var _this = this;
        this.sidenavClose = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.onSidenavClose = function () {
            _this.sidenavClose.emit();
        };
    }
    SidenavListComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SidenavListComponent.prototype, "sidenavClose", void 0);
    SidenavListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sidenav-list',
            template: __webpack_require__(/*! ./sidenav-list.component.html */ "./src/app/navigation/sidenav-list/sidenav-list.component.html"),
            styles: [__webpack_require__(/*! ./sidenav-list.component.sass */ "./src/app/navigation/sidenav-list/sidenav-list.component.sass")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SidenavListComponent);
    return SidenavListComponent;
}());



/***/ }),

/***/ "./src/app/routing/routing.module.ts":
/*!*******************************************!*\
  !*** ./src/app/routing/routing.module.ts ***!
  \*******************************************/
/*! exports provided: RoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RoutingModule", function() { return RoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _credit_credit_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../credit/credit.component */ "./src/app/credit/credit.component.ts");





var routes = [
    { path: 'home', component: _credit_credit_component__WEBPACK_IMPORTED_MODULE_4__["CreditComponent"] },
    { path: 'credit', component: _credit_credit_component__WEBPACK_IMPORTED_MODULE_4__["CreditComponent"] },
    { path: '', redirectTo: '/credit', pathMatch: 'full' }
];
var RoutingModule = /** @class */ (function () {
    function RoutingModule() {
    }
    RoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forRoot(routes)
            ],
            exports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]
            ],
        })
    ], RoutingModule);
    return RoutingModule;
}());



/***/ }),

/***/ "./src/app/scanqr/scanqr.component.html":
/*!**********************************************!*\
  !*** ./src/app/scanqr/scanqr.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  scanqr works!\n</p>\n"

/***/ }),

/***/ "./src/app/scanqr/scanqr.component.sass":
/*!**********************************************!*\
  !*** ./src/app/scanqr/scanqr.component.sass ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NjYW5xci9zY2FucXIuY29tcG9uZW50LnNhc3MifQ== */"

/***/ }),

/***/ "./src/app/scanqr/scanqr.component.ts":
/*!********************************************!*\
  !*** ./src/app/scanqr/scanqr.component.ts ***!
  \********************************************/
/*! exports provided: ScanqrComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScanqrComponent", function() { return ScanqrComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ScanqrComponent = /** @class */ (function () {
    function ScanqrComponent() {
    }
    ScanqrComponent.prototype.ngOnInit = function () {
    };
    ScanqrComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-scanqr',
            template: __webpack_require__(/*! ./scanqr.component.html */ "./src/app/scanqr/scanqr.component.html"),
            styles: [__webpack_require__(/*! ./scanqr.component.sass */ "./src/app/scanqr/scanqr.component.sass")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ScanqrComponent);
    return ScanqrComponent;
}());



/***/ }),

/***/ "./src/app/services/credit.service.ts":
/*!********************************************!*\
  !*** ./src/app/services/credit.service.ts ***!
  \********************************************/
/*! exports provided: CreditService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreditService", function() { return CreditService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _AppConsts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../AppConsts */ "./src/app/AppConsts.ts");




var CreditService = /** @class */ (function () {
    function CreditService(http) {
        this.http = http;
    }
    CreditService.prototype.getUserCredit = function (username) {
        var url = _AppConsts__WEBPACK_IMPORTED_MODULE_3__["AppConsts"].webAdminBackendUrl;
        console.log('getusercredit ' + username + ' at ' + url);
        var data = this.http.get(url + '/api/services/app/UserCredits/GetUserCredit?userName=' + username);
        return data;
    };
    CreditService.prototype.startTransaction = function () {
        var url = _AppConsts__WEBPACK_IMPORTED_MODULE_3__["AppConsts"].magicBoxBackendurl;
        var post = this.http.post(url + "/api/machine/starttransaction", null);
        return post;
    };
    CreditService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], CreditService);
    return CreditService;
}());



/***/ }),

/***/ "./src/app/shared/XmlHttpRequestHelper.ts":
/*!************************************************!*\
  !*** ./src/app/shared/XmlHttpRequestHelper.ts ***!
  \************************************************/
/*! exports provided: XmlHttpRequestHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "XmlHttpRequestHelper", function() { return XmlHttpRequestHelper; });
var XmlHttpRequestHelper = /** @class */ (function () {
    function XmlHttpRequestHelper() {
    }
    XmlHttpRequestHelper.ajax = function (type, url, customHeaders, data, success) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var result = JSON.parse(xhr.responseText);
                    success(result);
                }
                else if (xhr.status !== 0) {
                    alert('InternalServerError');
                }
            }
        };
        xhr.open(type, url, true);
        for (var property in customHeaders) {
            if (customHeaders.hasOwnProperty(property)) {
                xhr.setRequestHeader(property, customHeaders[property]);
            }
        }
        xhr.setRequestHeader('Content-type', 'application/json');
        if (data) {
            xhr.send(data);
        }
        else {
            xhr.send();
        }
    };
    return XmlHttpRequestHelper;
}());



/***/ }),

/***/ "./src/assets/my-rx-stomp.config.ts":
/*!******************************************!*\
  !*** ./src/assets/my-rx-stomp.config.ts ***!
  \******************************************/
/*! exports provided: myRxStompConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "myRxStompConfig", function() { return myRxStompConfig; });
var myRxStompConfig = {
    // Which server?
    brokerURL: 'ws://192.168.1.112:15674/ws',
    // Headers
    // Typical keys: login, passcode, host
    connectHeaders: {
        login: 'admin',
        passcode: 'konbini62'
    },
    // How often to heartbeat?
    // Interval in milliseconds, set to 0 to disable
    heartbeatIncoming: 0,
    heartbeatOutgoing: 20000,
    // Wait in milliseconds before attempting auto reconnect
    // Set to 0 to disable
    // Typical value 500 (500 milli seconds)
    reconnectDelay: 200,
    // Will log diagnostics on console
    // It can be quite verbose, not recommended in production
    // Skip this key to stop logging to console
    debug: function (msg) {
        console.log(new Date(), msg);
    }
};


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Data\Konbini\TFS\StandardCloud\StandardCloud\V2\Konbi.MachineBrain\Devices\konbiwalletapp\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map